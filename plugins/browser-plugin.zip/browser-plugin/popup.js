const statusEl = document.getElementById("status");
const lastErrorEl = document.getElementById("lastError");
const portEl = document.getElementById("port");
const saveEl = document.getElementById("save");

function renderStatus(status) {
	statusEl.textContent = `状态: ${status.status} (端口 ${status.port})`;
	statusEl.className = status.status;
	lastErrorEl.textContent = status.lastError ?? "";
}

async function refresh() {
	const status = await chrome.runtime.sendMessage({ type: "status" });
	renderStatus(status);
	portEl.value = status.port;
}

saveEl.addEventListener("click", async () => {
	const port = Number(portEl.value);
	if (!Number.isInteger(port) || port <= 0 || port >= 65536) return;
	await chrome.storage.local.set({ omegaBridgePort: port });
	await chrome.runtime.sendMessage({ type: "reconnect" });
	setTimeout(refresh, 500);
});

refresh();
