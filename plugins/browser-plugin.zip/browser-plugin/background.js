// Omega Browser Bridge — MV3 service worker.
// Connects to the Omega bridge server (default ws://127.0.0.1:9334) and executes
// browser-control commands sent by the Omega agent. Reconnects with backoff.

const DEFAULT_PORT = 9334;
const RECONNECT_MIN_MS = 1000;
const RECONNECT_MAX_MS = 30000;
const MAX_TEXT_LENGTH = 50000;

let socket = null;
let reconnectTimer = null;
let reconnectDelay = RECONNECT_MIN_MS;
let port = DEFAULT_PORT;
let lastError = "";
let connectGeneration = 0;

chrome.runtime.onInstalled.addListener(bootstrap);
chrome.runtime.onStartup.addListener(bootstrap);
bootstrap();

async function bootstrap() {
	port = await loadPort();
	connect();
}

chrome.storage.onChanged.addListener((changes, area) => {
	if (area === "local" && changes.omegaBridgePort) {
		port = normalizePort(changes.omegaBridgePort.newValue);
		reconnectNow();
	}
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
	if (message?.type === "status") {
		sendResponse({
			port,
			status: socket ? "connected" : lastError ? "error" : reconnectTimer ? "reconnecting" : "disconnected",
			lastError,
		});
		return;
	}
	if (message?.type === "reconnect") {
		reconnectNow();
		sendResponse({ ok: true });
	}
});

async function loadPort() {
	const stored = await chrome.storage.local.get("omegaBridgePort");
	return normalizePort(stored.omegaBridgePort);
}

function normalizePort(value) {
	const parsed = Number(value);
	return Number.isInteger(parsed) && parsed > 0 && parsed < 65536 ? parsed : DEFAULT_PORT;
}

function connect() {
	connectGeneration += 1;
	const generation = connectGeneration;
	if (socket) {
		try {
			socket.close();
		} catch {
			// already closing
		}
		socket = null;
	}
	if (reconnectTimer) {
		clearTimeout(reconnectTimer);
		reconnectTimer = null;
	}

	const url = `ws://127.0.0.1:${port}`;
	try {
		socket = new WebSocket(url);
	} catch (error) {
		lastError = String(error);
		scheduleReconnect(generation);
		return;
	}

	socket.onopen = () => {
		lastError = "";
		reconnectDelay = RECONNECT_MIN_MS;
		send({ type: "hello", extension: "omega-browser-bridge", version: "1.0.0" });
	};

	socket.onmessage = (event) => {
		handleMessage(event.data).catch((error) => {
			lastError = String(error);
		});
	};

	socket.onclose = () => {
		if (socket) {
			socket = null;
		}
		scheduleReconnect(generation);
	};

	socket.onerror = () => {
		lastError = `Cannot reach ${url}`;
	};
}

function scheduleReconnect(generation) {
	if (generation !== connectGeneration) return;
	reconnectTimer = setTimeout(() => {
		reconnectTimer = null;
		connect();
	}, reconnectDelay);
	reconnectDelay = Math.min(reconnectDelay * 2, RECONNECT_MAX_MS);
}

function reconnectNow() {
	reconnectDelay = RECONNECT_MIN_MS;
	connect();
}

function send(payload) {
	if (socket?.readyState === WebSocket.OPEN) {
		socket.send(JSON.stringify(payload));
	}
}

async function handleMessage(raw) {
	let request;
	try {
		request = JSON.parse(raw);
	} catch {
		return;
	}
	if (request.type !== "command" || typeof request.id !== "number") return;

	let response;
	try {
		const result = await dispatch(request.tool, request.params ?? {});
		response = { id: request.id, ok: true, result };
	} catch (error) {
		response = { id: request.id, ok: false, error: error instanceof Error ? error.message : String(error) };
	}
	send(response);
}

async function dispatch(tool, params) {
	switch (tool) {
		case "ping":
			return { pong: true };
		case "list_tabs":
			return listTabs();
		case "select_tab":
			return selectTab(Number(params.tabId));
		case "navigate":
			return navigate(params);
		case "evaluate":
			return evaluate(await resolveTabId(params), String(params.expression));
		case "get_content":
			return getContent(await resolveTabId(params), params);
		case "screenshot":
			return screenshot(await resolveTabId(params));
		case "click":
			return click(await resolveTabId(params), String(params.selector));
		case "type":
			return type(await resolveTabId(params), String(params.selector), String(params.text));
		default:
			throw new Error(`Unknown tool: ${tool}`);
	}
}

async function resolveTabId(params) {
	if (params.tabId !== undefined && params.tabId !== null) return Number(params.tabId);
	const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	if (!tab?.id) throw new Error("No active tab in the current window");
	return tab.id;
}

function tabToResult(tab) {
	return { tabId: tab.id, title: tab.title, url: tab.url, active: tab.active, windowId: tab.windowId };
}

async function listTabs() {
	const tabs = await chrome.tabs.query({});
	return tabs.filter((tab) => typeof tab.id === "number").map(tabToResult);
}

async function selectTab(tabId) {
	const tab = await chrome.tabs.update(tabId, { active: true });
	if (!tab) throw new Error(`Tab not found: ${tabId}`);
	return tabToResult(tab);
}

async function navigate(params) {
	const url = String(params.url ?? "");
	if (!url) throw new Error("url is required");
	if (params.tabId === undefined || params.tabId === null) {
		const tab = await chrome.tabs.create({ url, active: true });
		return { created: true, ...tabToResult(tab) };
	}
	const tab = await chrome.tabs.update(Number(params.tabId), { url });
	if (!tab) throw new Error(`Tab not found: ${params.tabId}`);
	return { created: false, ...tabToResult(tab) };
}

async function evaluate(tabId, expression) {
	const [injection] = await chrome.scripting.executeScript({
		target: { tabId },
		world: "MAIN",
		func: (expr) => {
			try {
				const value = eval(expr);
				return { ok: true, value: JSON.parse(JSON.stringify(value ?? null)) };
			} catch (error) {
				return { ok: false, error: String(error) };
			}
		},
		args: [expression],
	});
	const outcome = injection?.result;
	if (!outcome) throw new Error(`Script returned no result for tab ${tabId}`);
	if (!outcome.ok) throw new Error(outcome.error);
	return outcome.value;
}

async function getContent(tabId, params) {
	const maxLength = Number.isFinite(Number(params.maxLength)) ? Number(params.maxLength) : MAX_TEXT_LENGTH;
	const [injection] = await chrome.scripting.executeScript({
		target: { tabId },
		func: (limit) => ({
			title: document.title,
			url: location.href,
			text: (document.body?.innerText ?? "").slice(0, limit),
			html: (document.documentElement?.outerHTML ?? "").slice(0, limit),
		}),
		args: [maxLength],
	});
	const content = injection?.result;
	if (!content) throw new Error(`Script returned no result for tab ${tabId}`);
	return content;
}

async function screenshot(tabId) {
	const tab = await chrome.tabs.get(tabId);
	if (!tab.id) throw new Error(`Tab not found: ${tabId}`);
	const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
	return { dataUrl };
}

async function click(tabId, selector) {
	const [injection] = await chrome.scripting.executeScript({
		target: { tabId },
		world: "MAIN",
		func: (sel) => {
			const element = document.querySelector(sel);
			if (!element) return { ok: false, error: `Element not found: ${sel}` };
			element.scrollIntoView({ block: "center" });
			element.click();
			return { ok: true };
		},
		args: [selector],
	});
	const outcome = injection?.result;
	if (!outcome) throw new Error(`Script returned no result for tab ${tabId}`);
	if (!outcome.ok) throw new Error(outcome.error);
	return { clicked: selector };
}

async function type(tabId, selector, text) {
	const [injection] = await chrome.scripting.executeScript({
		target: { tabId },
		world: "MAIN",
		func: (sel, value) => {
			const element = document.querySelector(sel);
			if (!element) return { ok: false, error: `Element not found: ${sel}` };
			element.scrollIntoView({ block: "center" });
			element.focus();
			const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set ??
				Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
			if (setter) {
				setter.call(element, value);
			} else {
				element.value = value;
			}
			element.dispatchEvent(new Event("input", { bubbles: true }));
			element.dispatchEvent(new Event("change", { bubbles: true }));
			return { ok: true };
		},
		args: [selector, text],
	});
	const outcome = injection?.result;
	if (!outcome) throw new Error(`Script returned no result for tab ${tabId}`);
	if (!outcome.ok) throw new Error(outcome.error);
	return { typed: selector, length: text.length };
}
