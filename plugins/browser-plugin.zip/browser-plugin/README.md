# Omega Browser Bridge（浏览器分支）

让 Omega 智能体控制**用户日常使用的 Chrome**（保留登录态、Cookie、已登录会话），与 `chrome_devtools_*` 系列工具的 CDP 模式（自动启动独立临时 Profile）互补。

## 组成

- 本目录（`plugins/browser-plugin/`）：Chrome MV3 扩展，作为 WebSocket 客户端连接 Omega。
- `packages/omega-core/src/browser-extension/`：Omega 侧桥接模块，启动 `ws://127.0.0.1:9334`（可用环境变量 `OMEGA_BROWSER_BRIDGE_PORT` 覆盖）并注册 `browser_ext_*` 工具。

## 安装

1. 打开 Chrome，访问 `chrome://extensions`。
2. 右上角开启「开发者模式」。
3. 点击「加载已解压的扩展程序」，选择本目录（`plugins/browser-plugin`）。
4. 扩展会在安装后自动连接本机桥接端口；Omega 会话启动时自动开启桥接服务端。

## 智能体工具

| 工具 | 说明 |
| --- | --- |
| `browser_ext_status` | 查看桥接服务端与扩展连接状态 |
| `browser_ext_list_tabs` | 列出所有标签页 |
| `browser_ext_select_tab` | 将指定标签页置前 |
| `browser_ext_navigate` | 导航（可新建标签页） |
| `browser_ext_evaluate` | 在页面主世界执行 JS（结果需可 JSON 序列化） |
| `browser_ext_get_content` | 读取标题 / URL / 可见文本 / HTML |
| `browser_ext_screenshot` | 截取可见区域并保存为 PNG（临时目录） |
| `browser_ext_click` | 点击 CSS 选择器匹配的元素 |
| `browser_ext_type` | 设置输入框值并派发 input/change 事件 |

CLI 命令：`/browser-bridge status|start|stop`。

## 协议

扩展 ↔ Omega 之间为 JSON 文本帧：

- 扩展 → Omega 握手：`{"type":"hello","extension":"omega-browser-bridge","version":"1.0.0"}`
- Omega → 扩展 命令：`{"type":"command","id":1,"tool":"navigate","params":{"url":"https://example.com"}}`
- 扩展 → Omega 响应：`{"id":1,"ok":true,"result":{...}}` 或 `{"id":1,"ok":false,"error":"..."}`

## 局限

- `evaluate` 在页面主世界使用 `eval`，受页面 CSP 限制的站点可能失败；此时改用 `get_content`。
- `screenshot` 依赖 `chrome.tabs.captureVisibleTab`，只能截取当前可见区域且标签页需在前台窗口。
- 桥接仅监听 `127.0.0.1`，不出本机；扩展具备 `<all_urls>` 脚本注入权限，请只在可信环境安装。
